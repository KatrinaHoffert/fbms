-------------------------------------------------------------------------------
                FBMS: File Backup and Management System
-------------------------------------------------------------------------------
    Copyright (C) 2013 Hoffert, Rizvi, Alsharif, Tao, and Butler
                       mlh374  sar457   haa775  dat293    mdb815

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
-------------------------------------------------------------------------------

FBMS is an automated backup system written in Java. It keeps track of file
changes and stores older revisions of files.

For documentation on this project, see the wiki:
   https://code.google.com/p/fbms/wiki/Documentation

To import the project into Eclipse:
	- Go to File > Import
	- Under "General", choose "Existing Projects into Workspace"
	- As the root directory, choose the folder containing this file, which
	  should also contain a file named ".classpath" and a file named
	  ".project"
	- Leave everything else at the default and choose "finish". The project
	  should now be imported into the package explorer.
	- To verify the importation was successful, attempt to run the program.
	  It should be able to find all the imported packages.