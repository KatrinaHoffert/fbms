package cmpt370.fbms;

public class FrontEnd
{
	private String parseTime(int timestamp)
	{
		return null;
	}

	private String parseSize(int filesize)
	{
		return null;
	}
}
