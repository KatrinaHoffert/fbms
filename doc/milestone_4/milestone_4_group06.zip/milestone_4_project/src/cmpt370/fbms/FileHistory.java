package cmpt370.fbms;

import java.nio.file.Path;

public class FileHistory
{
	public static Path getRevision(Path file, long timestamp)
	{
		return null;
	}

	public static void storeRevision(Path diff, long filesize, long delta)
	{

	}

	public static Path obtainRevision(Path file, long timestamp)
	{
		return null;
	}

	public static void renameRevision(Path file, String newName)
	{

	}
}
