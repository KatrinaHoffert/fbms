package cmpt370.fbms;

import java.nio.file.Path;

public class RenamedFile
{
	public Path oldName;
	public Path newName;
}
