package cmpt370.fbms;

public class RevisionInfo
{
	public long id;
	public String path;
	public String diff;
	public long delta;
	public long time;
}
